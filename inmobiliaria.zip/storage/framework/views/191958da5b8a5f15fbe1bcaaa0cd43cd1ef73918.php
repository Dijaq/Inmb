

<?php $__env->startSection('contenido'); ?>

<div class="card" align="center" style="width: 70%; margin-left: 15%;  ">
    <div class="card-header">
      <h4 class="card-title">Inmueble</h4>
    </div>
    <div class="card-body">

 <!-- <div align="center">
  <h2 style="text-align:center;">Inmueble</h2>
  <br>-->
  <?php if(session()->has('info')): ?>
    <h3><?php echo e(session('info')); ?></h3>
  <?php else: ?>
      <!--<form action="/file-upload"
        class="dropzone"
        id="my-awesome-dropzone">
      </form>-->

      <div align="center">
        <form method="POST" action="<?php echo e(route('inmueble.store')); ?>" enctype="multipart/form-data">
        
          <?php echo csrf_field(); ?>

        
          <div class="row">
            
             <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Título</label>
                <input class="form-control" type="text" name="titulo" value="<?php echo e(old('titulo')); ?>">
                  <?php echo $errors->first('titulo', '<span class="error">:message</span>'); ?>

              </div>
            </div>
            
            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Tipo Inmueble</label>
                <select class="form-control" name="tipo" required>
                  <option value="">[Seleccion una opción]</option>
                  <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($tipo->id); ?>" <?php echo e(old('tipo') == $tipo->id ? 'selected':''); ?>><?php echo e($tipo->nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Tipo Operación</label>
                <select class="form-control" name="operacion" required>
                  <option value="">[Seleccion una opción]</option>
                  <?php $__currentLoopData = $operaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($operacion->id); ?>" <?php echo e(old('operacion') == $operacion->id ? 'selected':''); ?>><?php echo e($operacion->nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Ubicación</label>
                <select class="form-control" name="ubicacion" required>
                  <option value="">[Seleccion una opción]</option>
                  <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($ubicacion->id); ?>" <?php echo e(old('ubicacion') == $ubicacion->id ? 'selected':''); ?>><?php echo e($ubicacion->info_busqueda); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>


            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Dirección</label>
                <input class="form-control" type="text" name="direccion" value="<?php echo e(old('direccion')); ?>">
                  <?php echo $errors->first('direccion', '<span class="error">:message</span>'); ?>

              </div>
            </div>            

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Descripción</label>
                <input class="form-control" type="text" name="descripcion" value="<?php echo e(old('descripcion')); ?>">
                  <?php echo $errors->first('descripcion', '<span class="error">:message</span>'); ?>

              </div>
            </div>  

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="moneda" style="text-align:left;">Moneda</label>
                <select class="form-control" name="moneda" required>
                  <option value="">[Seleccion una opción]</option>
                  <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($moneda['id']); ?>" <?php echo e(old('moneda') == $moneda['id'] ? 'selected':''); ?>><?php echo e($moneda['nombre']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Precio</label>
                <input class="form-control" type="text" name="precio" value="<?php echo e(old('precio')); ?>">
                  <?php echo $errors->first('precio', '<span class="error">:message</span>'); ?>

              </div>
            </div>    

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="publicacion" >Días de Publicación</label>
                <input class="form-control" type="text" name="publicacion" value="<?php echo e(old('publicacion')); ?>">
                  <?php echo $errors->first('publicacion', '<span class="error">:message</span>'); ?>

              </div>
            </div>    
            
            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Imagen</label>
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="validatedCustomFile" name="dir_image">
                  <label class="custom-file-label" for="validatedCustomFile">Elige una imagen</label>
                  <div class="invalid-feedback">Example invalid custom file feedback</div>
                  <?php echo $errors->first('dir_image', '<span class="error">:message</span>'); ?>

                </div>
              </div>
            </div>

            

          </div>
          <div class="row">
            <div class="col-md-12"><input class="btn btn-primary" type="submit" value="Crear Inmueble"></div>
          </div>
          <br><br>
        
        </form>
      </div>

     
  <?php endif; ?>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutintranettim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/admin_inmuebles/inmuebles/create.blade.php ENDPATH**/ ?>