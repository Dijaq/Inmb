

<?php $__env->startSection('contenido'); ?>

<div class="card" align="center" style="width: 70%; margin-left: 15%;  ">
    <div class="card-header">
      <h4 class="card-title">Inmueble</h4>
    </div>
    <div class="card-body">

 <!-- <div align="center">
  <h2 style="text-align:center;">Inmueble</h2>
  <br>-->
  <?php if(session()->has('info')): ?>
    <h3><?php echo e(session('info')); ?></h3>
  <?php else: ?>
      <!--<form action="/file-upload"
        class="dropzone"
        id="my-awesome-dropzone">
      </form>-->

      <div align="center">
        <form method="POST" action="<?php echo e(route('inmueble.store')); ?>" enctype="multipart/form-data">
        
          <?php echo csrf_field(); ?>

        
          <div class="row">
            
             <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Título</label>
                <input class="form-control" type="text" name="titulo" value="<?php echo e(old('titulo')); ?>">
                  <?php echo $errors->first('titulo', '<span class="error">:message</span>'); ?>

              </div>
            </div>
            
            <input class="form-control" type="hidden" name="tipo" value="<?php echo e($tipo); ?>">
            <!--<div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Tipo Inmueble</label>
                <select class="form-control" name="tipo" required>
                  <option value="">[Seleccione una opción]</option>
                  <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($tipo->id); ?>" <?php echo e(old('tipo') == $tipo->id ? 'selected':''); ?>><?php echo e($tipo->nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>-->

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Tipo Operación</label>
                <select class="form-control" name="operacion" required>
                  <option value="">[Seleccione una opción]</option>
                  <?php $__currentLoopData = $operaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($operacion->id); ?>" <?php echo e(old('operacion') == $operacion->id ? 'selected':''); ?>><?php echo e($operacion->nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <!--<div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="area" >Área</label>
                <input class="form-control" type="text" name="area" value="<?php echo e(old('area')); ?>">
                  <?php echo $errors->first('area', '<span class="error">:message</span>'); ?>

              </div>
            </div>-->

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Ubicación</label>
                <select class="form-control" name="ubicacion" required>
                  <option value="">[Seleccione una opción]</option>
                  <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($ubicacion->id); ?>" <?php echo e(old('ubicacion') == $ubicacion->id ? 'selected':''); ?>><?php echo e($ubicacion->info_busqueda); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>


            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Dirección</label>
                <input class="form-control" type="text" name="direccion" value="<?php echo e(old('direccion')); ?>">
                  <?php echo $errors->first('direccion', '<span class="error">:message</span>'); ?>

              </div>
            </div>            

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="descripcion" >Descripción</label>
                <textarea rows="8" class="form-control" type="text" id="editor" name="descripcion" value="<?php echo e(old('descripcion')); ?>"></textarea>
                  <?php echo $errors->first('descripcion', '<span class="error">:message</span>'); ?>

              </div>
            </div>  

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="moneda" style="text-align:left;">Moneda</label>
                <select class="form-control" name="moneda" required>
                  <option value="">[Seleccion una opción]</option>
                  <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($moneda['id']); ?>" <?php echo e(old('moneda') == $moneda['id'] ? 'selected':''); ?>><?php echo e($moneda['nombre']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Precio</label>
                <input class="form-control" type="number" step='0.01' name="precio" value="<?php echo e(old('precio')); ?>">
                  <?php echo $errors->first('precio', '<span class="error">:message</span>'); ?>

              </div>
            </div>    

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="publicacion" >Días de Publicación</label>
                <input class="form-control" type="text" name="publicacion" value="<?php echo e(old('publicacion')); ?>">
                  <?php echo $errors->first('publicacion', '<span class="error">:message</span>'); ?>

              </div>
            </div>    
            
            <div class="col-md-12" style="text-align:left;">
                <label for="tipo" style="text-align:left;">Imágenes</label>
                <input type="file" name="dir_images[]" id="image" multiple class="form-control" required>
                <!--<div class="custom-file">
                  <input type="file" class="custom-file-input" id="validatedCustomFile" name="dir_image">
                  <label class="custom-file-label" for="validatedCustomFile">Elige una imagen</label>
                  <div class="invalid-feedback">Example invalid custom file feedback</div>
                  <?php echo $errors->first('dir_image', '<span class="error">:message</span>'); ?>

                </div>-->
            </div>
            
            <div class="col-md-12" style="text-align:center;">
              <h4 class="card-title">Atributos</h4>
            </div>

            <?php $__currentLoopData = $atributos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atributo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4" style="text-align:left;">

                <?php if($atributo->tipo_opcion == 1): ?>

                  <div class="form-group">
                    <label for="tipo" style="text-align:left;"><?php echo e($atributo->nombre); ?></label>
                    
                      <select class="form-control" name="atributo_<?php echo e($atributo->id); ?>" required>
                      <option value="">[Seleccione una opción]</option>
                      <?php $__currentLoopData = explode(",",$atributo->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                          <option value="<?php echo e($value); ?>" <?php echo e(old('atributo-1') == $value ? 'selected':''); ?>><?php echo e($value); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>   
                  </div>
                <?php elseif($atributo->tipo_opcion == 2): ?>
                  <div class="col-md-12" style="text-align:left;">
                    <div class="form-group">
                      <label for="publicacion" ><?php echo e($atributo->nombre); ?></label>
                      <input class="form-control" type="text" name="atributo_<?php echo e($atributo->id); ?>" value="<?php echo e(old('publicacion')); ?>">
                        <?php echo $errors->first('publicacion', '<span class="error">:message</span>'); ?>

                    </div>
                  </div>    
                  <!--<label for="tipo" style="text-align:left;"><?php echo e($atributo->nombre); ?></label>
                  <?php $__currentLoopData = explode(",",$atributo->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="form-check">
                      <label class="form-check-label">
                          <input class="form-check-input" type="checkbox" value=<?php echo e($value); ?>>
                          <?php echo e($value); ?>

                          <span class="form-check-sign">
                              <span class="check"></span>
                          </span>
                      </label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                <?php else: ?>
                  <label for="tipo" style="text-align:left;"><?php echo e($atributo->nombre); ?></label>
                  <?php $__currentLoopData = explode(",",$atributo->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="radio">
                      <label>
                        <input type="radio" name="atributo_<?php echo e($atributo->id); ?>" value="<?php echo e($value); ?>">
                        <?php echo e($value); ?>

                      </label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-12" style="text-align:center;">
              <h4 class="card-title">Servicios</h4>
            </div>

            <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4" style="text-align:left;">

                <?php if($servicio->tipo_opcion == 1): ?>

                  <div class="form-group">
                    <label for="tipo" style="text-align:left;"><?php echo e($servicio->nombre); ?></label>
                    
                      <select class="form-control" name="atributo_<?php echo e($servicio->id); ?>">
                      <option value="">[Seleccione una opción]</option>
                      <?php $__currentLoopData = explode(",",$servicio->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                          <option value="<?php echo e($value); ?>" <?php echo e(old('atributo-1') == $value ? 'selected':''); ?>><?php echo e($value); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>   
                  </div>
                <?php elseif($servicio->tipo_opcion == 2): ?>
                  
                  <div class="form-group">
                    <label for="publicacion" ><?php echo e($servicio->nombre); ?></label>
                    <input class="form-control" type="text" name="servicio_<?php echo e($servicio->id); ?>" value="<?php echo e(old('publicacion')); ?>">
                      <?php echo $errors->first('publicacion', '<span class="error">:message</span>'); ?>

                  </div>
                     
                  <!--<label for="tipo" style="text-align:left;"><?php echo e($servicio->nombre); ?></label>
                  <?php $__currentLoopData = explode(",",$servicio->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="form-check">
                      <label class="form-check-label">
                          <input class="form-check-input" type="checkbox" value=<?php echo e($value); ?>>
                          <?php echo e($value); ?>

                          <span class="form-check-sign">
                              <span class="check"></span>
                          </span>
                      </label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                <?php else: ?>
                  <label for="tipo" style="text-align:left;"><?php echo e($servicio->nombre); ?></label>
                  <?php $__currentLoopData = explode(",",$servicio->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="radio">
                      <label>
                        <input type="radio" name="servicio_<?php echo e($servicio->id); ?>" value="<?php echo e($value); ?>">
                        <?php echo e($value); ?>

                      </label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>

          <div class="row">
            <div class="col-md-12"><input class="btn btn-primary" type="submit" value="Crear Inmueble"></div>
          </div>
          <br><br>
        
        </form>
      </div>

     
  <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutintranettim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/admin_inmuebles/inmuebles/create.blade.php ENDPATH**/ ?>