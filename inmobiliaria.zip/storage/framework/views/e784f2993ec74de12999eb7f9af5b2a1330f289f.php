

<?php $__env->startSection('contenido'); ?>

    <div class="section2">
      <div class="container py-5">
      <form method="POST" action="<?php echo e(route('publicar.update', $inmueble->id)); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>

            <?php echo csrf_field(); ?>

        
            <div class="row">
            
            <div class="col-md-12" style="text-align:left;">
                <div class="form-group">
                <!--<label for="titulo" >Título</label>-->
                <input placeholder="Título" class="form-control post__input maininput my-2 w-100" type="text" name="titulo" value="<?php echo e($inmueble->titulo); ?>">
                    <?php echo $errors->first('titulo', '<span class="error">:message</span>'); ?>

                </div>
            </div>

            <div class="col-md-6" style="text-align:left;">
                <div class="form-group">
                <!--<label for="tipo" style="text-align:left;">Tipo Operación</label>-->
                <select class="form-control w-100 post__input maininput my-2" name="operacion" required>
                    <?php $__currentLoopData = $operaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                        <?php if($inmueble->operacion_id == $operacion->id): ?>    
                        <option value="<?php echo e($operacion->id); ?>" selected="selected"><?php echo e($operacion->nombre); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($operacion->id); ?>"><?php echo e($operacion->nombre); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
            </div>

            <div class="col-md-6" style="text-align:left;">
                <div class="form-group">
                <!--<label for="tipo" style="text-align:left;">Ubicación</label>-->
                <select class="form-control w-100 post__input maininput my-2" name="ubicacion" required>
                    <option value="">[Ubicación]</option>
                    <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                        <<?php if($inmueble->ubigeo_distrito_id == $ubicacion->id): ?>    
                            <option value="<?php echo e($ubicacion->id); ?>" selected="selected"><?php echo e($ubicacion->info_busqueda); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($ubicacion->id); ?>"><?php echo e($ubicacion->info_busqueda); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
            </div>


            <div class="col-md-12" style="text-align:left;">
                <div class="form-group">
                <!--<label for="titulo" >Dirección</label>-->
                <input placeholder="Dirección" class="form-control post__input maininput my-2 w-100" type="text" name="direccion" value="<?php echo e($inmueble->direccion); ?>">
                    <?php echo $errors->first('direccion', '<span class="error">:message</span>'); ?>

                </div>
            </div>            

            <div class="col-md-12" style="text-align:left;">
                <div class="form-group">
                <!--<label for="descripcion" >Descripción</label>-->
                <textarea placeholder="Descripción" rows="8" class="form-control post__input maininput my-2 w-100" type="text" id="editor" name="descripcion" value="<?php echo e($inmueble->descripcion); ?>"><?php echo e($inmueble->descripcion); ?></textarea>
                    <?php echo $errors->first('descripcion', '<span class="error">:message</span>'); ?>

                </div>
            </div>  

            <div class="col-md-4" style="text-align:left;">
                <div class="form-group">
                <!--<label for="moneda" style="text-align:left;">Moneda</label>-->
                <select class="form-control w-100 post__input maininput my-2" name="moneda" required>
                    <option value="">[Moneda]</option>
                    <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                        <?php if($inmueble->moneda == $moneda['id']): ?>    
                            <option value="<?php echo e($moneda['id']); ?>" selected="selected"><?php echo e($moneda['nombre']); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($moneda['id']); ?>"><?php echo e($moneda['nombre']); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
            </div>

            <div class="col-md-4" style="text-align:left;">
                <div class="form-group">
                <!--<label for="titulo" >Precio</label>-->
                <input placeholder="Precio" class="form-control post__input maininput my-2 w-100" type="number" step="0.01" name="precio" value="<?php echo e($inmueble->precio); ?>" required>
                    <?php echo $errors->first('precio', '<span class="error">:message</span>'); ?>

                </div>
            </div>    

            <div class="col-md-4" style="text-align:left;">
                <div class="form-group">
                <!--<label for="publicacion" >Días de Publicación</label>-->
                <input placeholder="Agregar días de Publicación" class="form-control post__input maininput my-2 w-100" type="text" name="publicacion" value="0">
                    <?php echo $errors->first('publicacion', '<span class="error">:message</span>'); ?>

                </div>
            </div>    
            
            <div class="col-md-12" style="text-align:center;">
                <h4 class="card-title py-4">Atributos</h4>
            </div>

            <?php $__currentLoopData = $atributos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atributo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4" style="text-align:left;">

                <?php if($atributo->tipo_opcion == 1): ?>

                    <div class="form-group">
                    <label for="tipo" style="text-align:left;"><?php echo e($atributo->nombre); ?></label>
                    
                        <select class="form-control w-100 post__input maininput my-2" name="atributo_<?php echo e($atributo->id); ?>" required>
                        <option value="">[Seleccione una opción]</option>
                        <?php $__currentLoopData = explode(",",$atributo->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                            <?php if($atributo->inmueble_value == $value): ?>    
                                <option value="<?php echo e($value); ?>" selected="selected"><?php echo e($value); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>   
                    </div>
                <?php elseif($atributo->tipo_opcion == 2): ?>
                    
                    <div class="form-group">
                        <!--<label for="publicacion" ><?php echo e($atributo->nombre); ?></label>-->
                        <input placeholder="<?php echo e($atributo->nombre); ?>" class="form-control post__input maininput my-2 w-100" type="text" name="atributo_<?php echo e($atributo->id); ?>" value="<?php echo e($atributo->inmueble_value); ?>">
                        <?php echo $errors->first('publicacion', '<span class="error">:message</span>'); ?>

                    </div>
                       
                   
                <?php else: ?>
                    <label for="tipo" style="text-align:left;"><?php echo e($atributo->nombre); ?></label>
                    <?php $__currentLoopData = explode(",",$atributo->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="radio">
                        <label>
                        <?php if(strcmp($atributo->inmueble_value, $value) == 0): ?>
                        <input type="radio" name="atributo_<?php echo e($atributo->id); ?>" value="<?php echo e($value); ?>" checked>
                        <?php else: ?>
                            <input type="radio" name="atributo_<?php echo e($atributo->id); ?>" value="<?php echo e($value); ?>">
                        <?php endif; ?>
                        <?php echo e($value); ?>

                        </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-12" style="text-align:center;">
                <h4 class="card-title py-4">Servicios</h4>
            </div>

            <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4" style="text-align:left;">

                <?php if($servicio->tipo_opcion == 1): ?>

                    <div class="form-group">
                    <label for="tipo" style="text-align:left;"><?php echo e($servicio->nombre); ?></label>
                    
                        <select class="form-control w-100 post__input maininput my-2" name="atributo_<?php echo e($servicio->id); ?>">
                        <option value="">[Seleccione una opción]</option>
                        <?php $__currentLoopData = explode(",",$servicio->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                            <?php if($servicio->inmueble_value == $value): ?>
                                <option value="<?php echo e($value); ?>" selected="selected"><?php echo e($value); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>   
                    </div>
                <?php elseif($servicio->tipo_opcion == 2): ?>
                    
                    <div class="form-group">
                    <!--<label for="publicacion" ><?php echo e($servicio->nombre); ?></label>-->
                    <input placeholder="<?php echo e($servicio->nombre); ?>" class="form-control post__input maininput my-2 w-100" type="text" name="servicio_<?php echo e($servicio->id); ?>" value="<?php echo e($servicio->inmueble_value); ?>">
                        <?php echo $errors->first('publicacion', '<span class="error">:message</span>'); ?>

                    </div>
               
                <?php else: ?>
                    <label for="tipo" style="text-align:left;"><?php echo e($servicio->nombre); ?></label>
                    <?php $__currentLoopData = explode(",",$servicio->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="radio">
                        <label>
                        <?php if(strcmp($servicio->inmueble_value, $value) == 0): ?>
                          <input type="radio" name="servicio_<?php echo e($servicio->id); ?>" value="<?php echo e($value); ?>" checked>
                        <?php else: ?>
                          <input type="radio" name="servicio_<?php echo e($servicio->id); ?>" value="<?php echo e($value); ?>">
                        <?php endif; ?>
                        <?php echo e($value); ?>

                        </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="row">
            <div class="col-md-12">
                <!--<input class="btn btn-primary" type="submit" value="Crear Inmueble">-->
                <button type="submit" class="btn mainButton mt-3 mainButton--shadow">
                    Actualizar Publicación
                </button>
            </div>
            </div>
            <br><br>
        
        </form>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutdescripcion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/general/editarInmueble.blade.php ENDPATH**/ ?>