

<?php $__env->startSection('contenido'); ?>

<div class="card" align="center" style="width: 70%; margin-left: 15%;  ">
    <div class="card-header">
      <h4 class="card-title">Inmueble</h4>
    </div>
    <div class="card-body">

 <!-- <div align="center">
  <h2 style="text-align:center;">Inmueble</h2>
  <br>-->
  <?php if(session()->has('info')): ?>
    <h3><?php echo e(session('info')); ?></h3>
  <?php else: ?>
      <!--<form action="/file-upload"
        class="dropzone"
        id="my-awesome-dropzone">
      </form>-->

      <div align="center">
        <form method="POST" action="<?php echo e(route('inmueble.create')); ?>" enctype="multipart/form-data">
        
          <?php echo csrf_field(); ?>

        
          <div class="row">
            
            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Tipo Inmueble</label>
                <select class="form-control" name="tipo" required>
                  <option value="">[Seleccione Tipo de Propiedad]</option>
                  <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($tipo->id); ?>" <?php echo e(old('tipo') == $tipo->id ? 'selected':''); ?>><?php echo e($tipo->nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>   

          </div>
          <div class="row">
            <div class="col-md-12"><input class="btn btn-primary" type="submit" value="Cargar Formulario"></div>
          </div>
          <br><br>
        
        </form>
      </div>

     
  <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutintranettim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/admin_inmuebles/inmuebles/seleccionar_tipo.blade.php ENDPATH**/ ?>