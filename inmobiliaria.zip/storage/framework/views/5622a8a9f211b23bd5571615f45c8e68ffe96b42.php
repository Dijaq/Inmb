

<?php $__env->startSection('contenido'); ?>

    <div class="section2">
      <div class="container py-5">
      <form method="POST" action="<?php echo e(route('publicar.create')); ?>" enctype="multipart/form-data">
        
        <?php echo csrf_field(); ?>

      
        <div class="row">
          
          <div class="col-md-12" style="text-align:left;">
            <div class="form-group">
              <!--<label for="tipo" style="text-align:left;">Tipo Inmueble</label>-->
              <select class="form-control w-100 post__input maininput my-2" name="tipo" required>
                <option value="">[Seleccione Tipo de Propiedad]</option>
                <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                    <option value="<?php echo e($tipo->id); ?>" <?php echo e(old('tipo') == $tipo->id ? 'selected':''); ?>><?php echo e($tipo->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>   

        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="mt-3">
            <button type="submit" class="btn mainButton mt-3 mainButton--shadow">
                Cargar Formulario
            </button>
            </div>
          </div>
        </div>
        <br><br>
      
      </form>
        
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutdescripcion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/general/seleccionar_tipo.blade.php ENDPATH**/ ?>