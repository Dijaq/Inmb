

<?php $__env->startSection('contenido'); ?>

  <h1>Atributos</h1>
  <a class="btn btn-primary" href="<?php echo e(route('general.inmueble')); ?>" style="float: right;">Crear Atributo</a>
  <br><br>
	<div class="table-responsive">
    <table class="table table-striped">
        <thead>
          <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th style="text-align: center">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $atributos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atributo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>  
                <td><?php echo e($atributo->id); ?></td>
                <td><?php echo e($atributo->nombre); ?></td>
                <td><?php echo e($atributo->ruta_imagen); ?></td>
                <td><?php echo e($atributo->meta); ?></td>
                <td><?php echo e($atributo->orden); ?></td>
                </td>

                <td align="center">
                  <a class="btn btn-info btn-sm" href="<?php echo e(route('atributo.edit', $atributo->id)); ?>">Editar</a>
                  <form style="display: inline" method="POST" action=<?php echo e(route('atributo.deshabilitar', $tipo->id)); ?>>
                    <?php echo csrf_field(); ?>

                    <?php echo method_field('DELETE'); ?>

                    <button class="btn btn-danger btn-sm">Eliminar</button>
                  </form>
                </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/administracion/atributos/index.blade.php ENDPATH**/ ?>