

<?php $__env->startSection('contenido'); ?>

<div class="publications section">
  <div class="container py-5">
    <h2 class="publication__title text-center">Gelería de Fotos de <?php echo e($inmueble->titulo); ?></h2>
    <div class="row mt-5">
      <div class="col-lg-12 col-md-12 mb-5">
        <div class="publication__card" style="padding: 20px;">

          <!-- <div align="center">
            <h2 style="text-align:center;">Inmueble</h2>
            <br>-->
            <?php if(session()->has('info')): ?>
              <h3><?php echo e(session('info')); ?></h3>
            <?php else: ?>
                <!--<form action="/file-upload"
                  class="dropzone"
                  id="my-awesome-dropzone">
                </form>-->

                <div align="center">
                  <form method="POST" action="<?php echo e(route('publicInmuebleFotos.store')); ?>" enctype="multipart/form-data">
                  
                    <?php echo csrf_field(); ?>

                  
                    <div class="row">
                      
                      <input class="form-control" type="hidden" name="inmueble_id" value="<?php echo e($inmueble->id); ?>">
                        
                      <div class="col-md-12" style="text-align:left;">
                          <label for="tipo" style="text-align:left;">Imágenes</label>
                          <input type="file" name="dir_images[]" id="image" multiple class="form-control" required>
                      </div>
                  
                    </div>

                    <div class="row py-3">
                      <div class="col-md-12"><input class="btn btn-primary" type="submit" value="Cargar Imagenes"></div>
                    </div>                  
                  </form>
                </div>
            </div>
        </div>
      </div>
    </div>

</div>
     
  <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutgeneral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/general/inmueble_imagen/create.blade.php ENDPATH**/ ?>