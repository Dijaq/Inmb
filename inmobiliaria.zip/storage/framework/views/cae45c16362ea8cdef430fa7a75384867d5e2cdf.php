

<?php $__env->startSection('contenido'); ?>

  <div class="card">
    <div class="card-header">
      <h4 class="card-title"> Lista de Servicios</h4>
      <!--<a class="btn btn-primary" href="<?php echo e(route('servicio.create')); ?>">Crear Servicio</a>-->
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table">
          <thead class="">
            <th>Id</th>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Ruta Imagen</th>
            <th>Meta</th>
            <th>Orden</th>
            <!--<th style="text-align: center">Acciones</th>-->
          </thead>
          <tbody>
          <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>  
                <td><?php echo e($servicio->id); ?></td>
                <td><?php echo e($servicio->nombre); ?></td>
                <td><?php echo e($servicio->tipo->nombre); ?></td>
                <td><?php echo e($servicio->ruta_imagen); ?></td>
                <td><?php echo e($servicio->meta); ?></td>
                <td><?php echo e($servicio->orden); ?></td>

                <!--<td align="center">
                  <a class="btn btn-info btn-sm" href="<?php echo e(route('servicio.edit', $servicio->id)); ?>">Editar</a>
                  <form style="display: inline" method="POST" action=<?php echo e(route('servicio.delete', $servicio->id)); ?>>
                    <?php echo csrf_field(); ?>

                    <?php echo method_field('DELETE'); ?>

                    <button class="btn btn-danger btn-sm">Eliminar</button>
                  </form>
                </td>-->
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutintranettim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/administracion/servicios/index.blade.php ENDPATH**/ ?>