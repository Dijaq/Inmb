

<?php $__env->startSection('contenido'); ?>

<div class="card" align="center" style="width: 70%; margin-left: 15%;  ">
    <div class="card-header">
      <h4 class="card-title">Gelería de Fotos de <?php echo e($inmueble->titulo); ?></h4>
    </div>
    <div class="card-body">

 <!-- <div align="center">
  <h2 style="text-align:center;">Inmueble</h2>
  <br>-->
  <?php if(session()->has('info')): ?>
    <h3><?php echo e(session('info')); ?></h3>
  <?php else: ?>
      <!--<form action="/file-upload"
        class="dropzone"
        id="my-awesome-dropzone">
      </form>-->

      <div align="center">
        <form method="POST" action="<?php echo e(route('inmuebleFotos.store')); ?>" enctype="multipart/form-data">
        
          <?php echo csrf_field(); ?>

        
          <div class="row">
            
            <input class="form-control" type="hidden" name="inmueble_id" value="<?php echo e($inmueble->id); ?>">
              
            <div class="col-md-12" style="text-align:left;">
                <label for="tipo" style="text-align:left;">Imágenes</label>
                <input type="file" name="dir_images[]" id="image" multiple class="form-control" required>
            </div>
        
          </div>

          <div class="row">
            <div class="col-md-12"><input class="btn btn-primary" type="submit" value="Cargar Imagenes"></div>
          </div>
          <br><br>
        
        </form>
      </div>

     
  <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutintranettim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/admin_inmuebles/inmueble_imagen/create.blade.php ENDPATH**/ ?>