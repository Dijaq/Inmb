

<?php $__env->startSection('contenido'); ?>

  <div align="center">
  <h2 style="text-align:center;">Servicio</h2>
  <br>
  <?php if(session()->has('info')): ?>
    <h3><?php echo e(session('info')); ?></h3>
  <?php else: ?>
      <!--<form action="/file-upload"
        class="dropzone"
        id="my-awesome-dropzone">
      </form>-->

      <div align="center">
        <form method="POST"  style="width: 60%;" action="<?php echo e(route('servicio.store')); ?>" enctype="multipart/form-data">
        
          <?php echo csrf_field(); ?>

        
          <div class="row">

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Nombre</label>
                <input class="form-control" type="text" name="nombre" value="<?php echo e(old('nombre')); ?>">
                  <?php echo $errors->first('nombre', '<span class="error">:message</span>'); ?>

              </div>
            </div>
            
            <input class="form-control" type="hidden" name="tipo" value="<?php echo e($tipo_id); ?>">

            <!--<div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Tipo Inmueble</label>
                <select class="form-control" name="tipo" required>
                  <option value="">[Seleccion una opción]</option>
                  <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($tipo->id); ?>" <?php echo e(old('tipo') == $tipo->id ? 'selected':''); ?>><?php echo e($tipo->nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>-->

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Tipo Atributo</label>
                <select class="form-control" name="tipo_opcion" required>
                  <option value="">[Seleccion una opción]</option>
                  <?php $__currentLoopData = $tipos_opcion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($tipo['id']); ?>" <?php echo e(old('tipo') == $tipo['id'] ? 'selected':''); ?>><?php echo e($tipo['nombre']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            
            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Icono</label>
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="validatedCustomFile" name="dir_image">
                  <label class="custom-file-label" for="validatedCustomFile">Elige una imagen</label>
                  <div class="invalid-feedback">Example invalid custom file feedback</div>
                  <?php echo $errors->first('dir_image', '<span class="error">:message</span>'); ?>

                </div>
              </div>
            </div>

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Meta</label>
                <input class="form-control" type="text" name="meta" value="<?php echo e(old('meta')); ?>">
                  <?php echo $errors->first('meta', '<span class="error">:message</span>'); ?>

              </div>
            </div>

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Orden</label>
                <input class="form-control" type="text" name="orden" value="<?php echo e(old('orden')); ?>">
                  <?php echo $errors->first('orden', '<span class="error">:message</span>'); ?>

              </div>
            </div>            

          </div>
          <div class="row">
            <div class="col-md-12"><input class="btn btn-primary" type="submit" value="Crear Servicio"></div>
          </div>
          <br><br>
        
        </form>
      </div>

     
  <?php endif; ?>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutintranettim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/administracion/servicios/create.blade.php ENDPATH**/ ?>