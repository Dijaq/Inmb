

<?php $__env->startSection('contenido'); ?>

<div class="publications section">
  <div class="container py-5">
    <h2 class="publication__title text-center">Gelería de Fotos de <?php echo e($inmueble->titulo); ?></h2>
    <div class="row mt-5">
      <div class="col-lg-12 col-md-12 mb-5">
        <div class="publication__card" style="padding: 20px;">
          <div class="py-2">
            <a class="btn btn-primary" href="<?php echo e(route('publicInmuebleFotos.create', $inmueble->id)); ?>">Nueva Foto</a>
          </div>
          <form method="POST" action="<?php echo e(route('publicInmuebleFotos.reordenar')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <input type="hidden" value="<?php echo e($inmueble->id); ?>" name="id">
              <div class="table-responsive">
                <table id="table_paginate_inmueble" class="table">
                  <thead class="">
                    <th>Orden</th>
                    <th>Principal</th>
                    <th>Imagen</th>
                    <th>Acciones</th>
                    <!--<th style="text-align: center">Acciones</th>-->
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $inmuebleFotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>  
                        <td><input class="form-control" type="text" name="orden_<?php echo e($foto->id); ?>" value="<?php echo e($foto->orden); ?>" style="width: 40px; text-align: center;"></td>
                        <td>
                        <div class="form-check">
                            <label class="form-check-label">
                                <?php if($foto->es_destacado): ?>
                                  <input class="form-check-input" name="destacado_<?php echo e($foto->id); ?>" type="checkbox" checked>     
                                <?php else: ?>
                                <input class="form-check-input" name="destacado_<?php echo e($foto->id); ?>" type="checkbox" >     
                                <?php endif; ?>
                                <span class="form-check-sign">
                                    <span class="check"></span>
                                </span>
                            </label>
                          </div>
                        </td>
                        <td><img src="<?php echo e(asset($foto->url_imagen)); ?>" style="width: 120px" alt="Card image cap"></td>
                        <td>
                          <a class="btn btn-info btn-sm" href="">Editar</a>
                          <form style="display: inline" method="POST" action=<?php echo e(route('publicInmuebleFotos.delete', $foto->id)); ?>>
                            <?php echo csrf_field(); ?>

                            <?php echo method_field('DELETE'); ?>

                            <button class="btn btn-danger btn-sm">Eliminar</button>
                          </form>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>

                <input class="btn btn-primary" type="submit" value="Reordenar">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutgeneral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/general/inmueble_imagen/index.blade.php ENDPATH**/ ?>