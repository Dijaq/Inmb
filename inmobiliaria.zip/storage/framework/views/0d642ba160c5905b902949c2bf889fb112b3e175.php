

<?php $__env->startSection('contenido'); ?>

  <div class="row">
    <div class="offset-md-3 col-md-6">
      <div class="card ">
          <div class="card-header ">
            <h4 class="card-title">Nuevo Tipo</h4>
          </div>
    <?php if(session()->has('info')): ?>
      <h3><?php echo e(session('info')); ?></h3>
    <?php else: ?>
        <div class="card-body ">
            <form style="width: 100%;" method="POST" action="<?php echo e(route('operacion.update', $operacion->id)); ?>">    
                <?php echo method_field('PUT'); ?>

                <?php echo csrf_field(); ?>     

                <label for="nombre" style="text-align:left;">
                Nombre Operación
                </label>
                <div class="form-group"><input class="form-control" type="text" name="nombre" value="<?php echo e($operacion->nombre); ?>">
                <?php echo $errors->first('nombre', '<span class="error">:message</span>'); ?></div>
                <br>
                <label for="nombre" style="text-align:left;">Orden</label>
                <div class="form-group"><input class="form-control" type="text" name="orden" value="<?php echo e($operacion->orden); ?>">
                <?php echo $errors->first('orden', '<span class="error">:message</span>'); ?></div>
                <br>
                <input class="btn btn-primary" type="submit" value="Editar">        
            </form>
        </div>  
      </div>
    </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutintranettim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/administracion/operacion/edit.blade.php ENDPATH**/ ?>