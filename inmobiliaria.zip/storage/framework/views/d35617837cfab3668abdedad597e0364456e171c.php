

<?php $__env->startSection('contenido'); ?>

<div class="card" align="center" style="width: 70%; margin-left: 15%;  ">
    <div class="card-header">
      <h4 class="card-title">Inmueble</h4>
    </div>
    <div class="card-body">

  <?php if(session()->has('info')): ?>
    <h3><?php echo e(session('info')); ?></h3>
  <?php else: ?>

      <div align="center">
        <form method="POST" action="<?php echo e(route('inmueble.update', $inmueble->id)); ?>" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>

          <?php echo csrf_field(); ?>

        
          <div class="row">
            
             <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Título</label>
                <input class="form-control" type="text" name="titulo" value="<?php echo e($inmueble->titulo); ?>">
                  <?php echo $errors->first('titulo', '<span class="error">:message</span>'); ?>

              </div>
            </div>

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Tipo Operación</label>
                <select class="form-control" name="operacion" required>
                  <?php $__currentLoopData = $operaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                    <?php if($inmueble->operacion_id == $operacion->id): ?>    
                      <option value="<?php echo e($operacion->id); ?>" selected="selected"><?php echo e($operacion->nombre); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($operacion->id); ?>"><?php echo e($operacion->nombre); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="area" >Área</label>
                <input class="form-control" type="text" name="area" value="<?php echo e($inmueble->area); ?>">
                  <?php echo $errors->first('area', '<span class="error">:message</span>'); ?>

              </div>
            </div>

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="tipo" style="text-align:left;">Ubicación</label>
                <select class="form-control" name="ubicacion" required>
                  <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <option value="<?php echo e($ubicacion->id); ?>" <?php echo e(old('ubicacion') == $ubicacion->id ? 'selected':''); ?>><?php echo e($ubicacion->info_busqueda); ?></option>
                    <?php if($inmueble->ubigeo_distrito_id == $ubicacion->id): ?>    
                      <option value="<?php echo e($ubicacion->id); ?>" selected="selected"><?php echo e($ubicacion->info_busqueda); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($ubicacion->id); ?>"><?php echo e($ubicacion->info_busqueda); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>


            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Dirección</label>
                <input class="form-control" type="text" name="direccion" value="<?php echo e($inmueble->direccion); ?>">
                  <?php echo $errors->first('direccion', '<span class="error">:message</span>'); ?>

              </div>
            </div>            

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="descripcion" >Descripción</label>
                <textarea rows="8" class="form-control" type="text" id="editor" name="descripcion" value="<?php echo e($inmueble->descripcion); ?>"><?php echo e($inmueble->descripcion); ?></textarea>
                  <?php echo $errors->first('descripcion', '<span class="error">:message</span>'); ?>

              </div>
            </div>  

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="moneda" style="text-align:left;">Moneda</label>
                <select class="form-control" name="moneda" required>
                  <?php $__currentLoopData = $monedas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                    <?php if($inmueble->moneda == $moneda['id']): ?>    
                      <option value="<?php echo e($moneda['id']); ?>" selected="selected"><?php echo e($moneda['nombre']); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($moneda['id']); ?>"><?php echo e($moneda['nombre']); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="titulo" >Precio</label>
                <input class="form-control" type="text" name="precio" value="<?php echo e($inmueble->precio); ?>">
                  <?php echo $errors->first('precio', '<span class="error">:message</span>'); ?>

              </div>
            </div>    

            <div class="col-md-12" style="text-align:left;">
              <div class="form-group">
                <label for="publicacion" >Aumentar N días de publicacion</label>
                <input class="form-control" type="text" name="publicacion" value="0">
                  <?php echo $errors->first('publicacion', '<span class="error">:message</span>'); ?>

              </div>
            </div>    
            
            <div class="col-md-12" style="text-align:center;">
              <h4 class="card-title">Atributos</h4>
            </div>

            <?php $__currentLoopData = $atributos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atributo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4" style="text-align:left;">

                <?php if($atributo->tipo_opcion == 1): ?>

                  <div class="form-group">
                    <label for="tipo" style="text-align:left;"><?php echo e($atributo->nombre); ?></label>
                    
                      <select class="form-control" name="atributo_<?php echo e($atributo->id); ?>" required>
                      <option value="">[Seleccione una opción]</option>
                      <?php $__currentLoopData = explode(",",$atributo->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                          <?php if($atributo->inmueble_value == $value): ?>    
                            <option value="<?php echo e($value); ?>" selected="selected"><?php echo e($value); ?></option>
                          <?php else: ?>
                              <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>   
                  </div>
                <?php elseif($atributo->tipo_opcion == 2): ?>
                  <label for="tipo" style="text-align:left;"><?php echo e($atributo->nombre); ?></label>
                  <?php $__currentLoopData = explode(",",$atributo->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="form-check">
                      <label class="form-check-label">
                          <input class="form-check-input" type="checkbox" value=<?php echo e($value); ?>>
                          <?php echo e($value); ?>

                          <span class="form-check-sign">
                              <span class="check"></span>
                          </span>
                      </label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <label for="tipo" style="text-align:left;"><?php echo e($atributo->nombre); ?></label>
                  <?php $__currentLoopData = explode(",",$atributo->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="radio">
                      <label>
                      <?php if(strcmp($atributo->inmueble_value, $value) == 0): ?>
                        <input type="radio" name="atributo_<?php echo e($atributo->id); ?>" value="<?php echo e($value); ?>" checked>
                      <?php else: ?>
                        <input type="radio" name="atributo_<?php echo e($atributo->id); ?>" value="<?php echo e($value); ?>">
                      <?php endif; ?>
                        <?php echo e($value); ?>

                      </label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-12" style="text-align:center;">
              <h4 class="card-title">Servicios</h4>
            </div>

            <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4" style="text-align:left;">

                <?php if($servicio->tipo_opcion == 1): ?>

                  <div class="form-group">
                    <label for="tipo" style="text-align:left;"><?php echo e($servicio->nombre); ?></label>
                    
                      <select class="form-control" name="atributo_<?php echo e($servicio->id); ?>">
                      <option value="">[Seleccione una opción]</option>
                      <?php $__currentLoopData = explode(",",$servicio->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                          <option value="<?php echo e($value); ?>" <?php echo e(old('atributo-1') == $value ? 'selected':''); ?>><?php echo e($value); ?></option>
                          <?php if($servicio->inmueble_value == $value): ?>
                            <option value="<?php echo e($value); ?>" selected="selected"><?php echo e($value); ?></option>
                          <?php else: ?>
                              <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>   
                  </div>
                <?php elseif($servicio->tipo_opcion == 2): ?>
                  <label for="tipo" style="text-align:left;"><?php echo e($servicio->nombre); ?></label>
                  <?php $__currentLoopData = explode(",",$servicio->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="form-check">
                      <label class="form-check-label">
                          <input class="form-check-input" type="checkbox" value=<?php echo e($value); ?>>
                          <?php echo e($value); ?>

                          <span class="form-check-sign">
                              <span class="check"></span>
                          </span>
                      </label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <label for="tipo" style="text-align:left;"><?php echo e($servicio->nombre); ?></label>
                  <?php $__currentLoopData = explode(",",$servicio->meta); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="radio">
                      <label>
                        <?php if(strcmp($servicio->inmueble_value, $value) == 0): ?>
                          <input type="radio" name="servicio_<?php echo e($servicio->id); ?>" value="<?php echo e($value); ?>" checked>
                        <?php else: ?>
                          <input type="radio" name="servicio_<?php echo e($servicio->id); ?>" value="<?php echo e($value); ?>">
                        <?php endif; ?>
                        <?php echo e($value); ?>

                      </label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>

          <div class="row">
            <div class="col-md-12"><input class="btn btn-primary" type="submit" value="Editar Inmueble"></div>
          </div>
          <br><br>
        
        </form>
      </div>

     
  <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutintranettim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/admin_inmuebles/inmuebles/edit.blade.php ENDPATH**/ ?>