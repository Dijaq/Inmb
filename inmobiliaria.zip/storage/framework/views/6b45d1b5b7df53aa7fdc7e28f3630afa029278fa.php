

<?php $__env->startSection('contenido'); ?>

<div class="card" align="center" style="width: 80%; margin-left: 10%;  ">
    <div class="card-header">
      <h4 class="card-title">Usuario</h4>
    </div>
    <div class="card-body">

 <!-- <div align="center">
  <h2 style="text-align:center;">Inmueble</h2>
  <br>-->
  <?php if(session()->has('info')): ?>
    <h3><?php echo e(session('info')); ?></h3>
  <?php else: ?>
      <!--<form action="/file-upload"
        class="dropzone"
        id="my-awesome-dropzone">
      </form>-->

      <div align="center">
        <form method="POST" action="<?php echo e(route('usuario.update', $usuario->id)); ?>" enctype="multipart/form-data">
          <?php echo method_field('PUT'); ?>

          <?php echo csrf_field(); ?>

        
          <div class="row">
            
             <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="nombres" >Nombres</label>
                <input class="form-control" type="text" name="nombres" value="<?php echo e($usuario->persona->nombres); ?>">
                  <?php echo $errors->first('nombres', '<span class="error">:message</span>'); ?>

              </div>
            </div>
            
            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="apellidos" >Apellidos</label>
                <input class="form-control" type="text" name="apellidos" value="<?php echo e($usuario->persona->apellidos); ?>">
                  <?php echo $errors->first('apellidos', '<span class="error">:message</span>'); ?>

              </div>
            </div>

            <div class="col-md-4" style="text-align:left;">
              <div class="form-group">
                <label for="dni" >Dni</label>
                <input class="form-control" type="text" name="dni" value="<?php echo e($usuario->persona->dni); ?>">
                  <?php echo $errors->first('dni', '<span class="error">:message</span>'); ?>

              </div>
            </div>
            
            <div class="col-md-4" style="text-align:left;">
              <div class="form-group">
                <label for="email" >Email</label>
                <input class="form-control" type="text" name="email" value="<?php echo e($usuario->persona->correo); ?>">
                  <?php echo $errors->first('email', '<span class="error">:message</span>'); ?>

              </div>
            </div>

            <div class="col-md-4" style="text-align:left;">
              <div class="form-group">
                <label for="celular" >Celular</label>
                <input class="form-control" type="text" name="celular" value="<?php echo e($usuario->persona->telefono); ?>">
                  <?php echo $errors->first('celular', '<span class="error">:message</span>'); ?>

              </div>
            </div>

            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="rol" style="text-align:left;">Rol</label>
                <select class="form-control" name="rol" required>
                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                    <?php if($usuario->rol == $rol['id']): ?>    
                      <option value="<?php echo e($rol['id']); ?>" selected="selected"><?php echo e($rol['nombre']); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($rol['id']); ?>"><?php echo e($rol['nombre']); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>


            <div class="col-md-6" style="text-align:left;">
              <div class="form-group">
                <label for="nombre_usuario" >Nombre Usuario</label>
                <input class="form-control" type="text" name="nombre_usuario" value="<?php echo e($usuario->nombre); ?>">
                  <?php echo $errors->first('nombre_usuario', '<span class="error">:message</span>'); ?>

              </div>
            </div>

          </div>
          <div class="row">
            <div class="col-md-12"><input class="btn btn-primary" type="submit" value="Editar Usuario"></div>
          </div>
          <br><br>
        
        </form>
      </div>

     
  <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutintranettim', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>