

<?php $__env->startSection('contenido'); ?>
    <div class="section2 descrip">
      <div class="container py-5">
        <div class="row mb-4">
          <div class="col-lg-8 col-md-8">
            <div class="row">
              <div class="col-lg-8">
                <h2 class="descrip__title">
                  <?php echo e($inmueble->titulo); ?>

                </h2>
              </div>
              <div class="col-lg-4">
                <div
                  class="d-flex align-items-center justify-content-end"
                  style="height: 100%"
                >
                  <?php $__currentLoopData = $inmueble_atributos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inmb_atributo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="d-flex flex-wrap align-items-center descrip__bed">
                    <img src="<?php echo e(asset('storage/'.$inmb_atributo->atributo->ruta_imagen)); ?>" class="descrip__icon mr-1" alt="" />
                    <div>
                      <span><?php echo e($inmb_atributo->valor); ?></span><br />
                      <span><?php echo e($inmb_atributo->atributo->nombre); ?></span>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <!--<div class="d-flex flex-wrap align-items-center descrip__bed">
                    <img src="<?php echo e(asset('storage/img/bed.png')); ?>" class="descrip__icon mr-1" alt="" />
                    <div>
                      <span>4</span><br />
                      <span>Habitaciones</span>
                    </div>
                  </div>
                  <div class="d-flex flex-wrap align-items-center descrip__bed">
                    <img src="<?php echo e(asset('storage/img/bath.png')); ?>" class="descrip__icon mr-1" alt="" />
                    <div>
                      <span>3</span><br />
                      <span>Baños</span>
                    </div>
                  </div>-->
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-4">
            <div class="d-flex justify-content-end mt-3">
              <?php if($inmueble->moneda == 'PEN'): ?>
                <span class="descrip__title">S/. <?php echo e($inmueble->precio); ?></span>
              <?php else: ?>
                <span class="descrip__title">$/. <?php echo e($inmueble->precio); ?></span>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-8 col-md-8">
            
                <div class="carousel slide" id="carousel-<?php echo e($inmueble->id); ?>" data-ride="carousel">
                  <div class="carousel-inner">
                      <div id="carouselExampleControls-<?php echo e($inmueble->id); ?>" class="carousel slide" data-ride="carousel">
                          <div class="carousel-inner">
                          <?php $__currentLoopData = $inmueble->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="carousel-item item<?php echo e($key == 0 ? ' active' : ''); ?>" id="item_<?php echo e($key); ?>">
                                  <img src="<?php echo e(asset($foto->url_imagen)); ?>" style="width: 100%" alt="Card image cap">
                              </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                          <a class="carousel-control-prev" href="#carouselExampleControls-<?php echo e($inmueble->id); ?>" role="button" data-slide="prev">
                              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                              <span class="sr-only">Previous</span>
                          </a>
                          <a class="carousel-control-next" href="#carouselExampleControls-<?php echo e($inmueble->id); ?>" role="button" data-slide="next">
                              <span class="carousel-control-next-icon" aria-hidden="true"></span>
                              <span class="sr-only">Next</span>
                          </a>
                      </div>
                  
                  </div>
              </div>
            <!--<img src="<?php echo e(asset($inmueble->fotos[0]->url_imagen)); ?>" class="w-100" alt="" />-->
            <div class="mt-5">
              <div class="descrip__paragraph">
                <h3 class="descrip__subtitle">Descripción</h3>
                <p>
                  <?php echo e($inmueble->descripcion); ?>

                </p>
              </div>

              <div
                  class="d-flex align-items-center justify-content-start py-4"
                  style="height: 100%"
                >
                <?php $__currentLoopData = $inmueble_servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inmb_servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="d-flex flex-wrap align-items-center descrip__bed">
                    <img src="<?php echo e(asset('storage/'.$inmb_servicio->servicio->ruta_imagen)); ?>" class="descrip__icon mr-1" alt="" />
                    <div>
                      <span><?php echo e($inmb_servicio->valor); ?></span><br />
                      <span><?php echo e($inmb_servicio->servicio->nombre); ?></span>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>    
              <div class="mt-4">
                <h3 class="descrip__subtitle">Ubicación</h3>
                <img src="<?php echo e(asset('storage/img/map-mini.png')); ?>" class="w-100" alt="" />
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 d-none d-md-block">
            <div class="d-flex flex-wrap justify-content-between">
                <?php $__currentLoopData = $inmueble->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div onclick="change(<?php echo e($key); ?>)">
                      <div class="descrip__mini"><img style="height: 100%" src="<?php echo e(asset($foto->url_imagen)); ?>" class="w-100" alt="" /></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <!--<div class="descrip__mini"><img style="height: 100%" src="<?php echo e(asset($inmueble->fotos[0]->url_imagen)); ?>" class="w-100" alt="" /></div>
              <div class="descrip__mini"></div>
              <div class="descrip__mini"></div>
              <div class="descrip__mini"></div>
              <div class="descrip__mini"></div>
              <div class="descrip__mini"></div>
              <div class="descrip__mini"></div>
              <div class="descrip__mini"></div>
              <div
                class="descrip__mini d-flex align-items-center justify-content-center"
              >
                <span>+10</span>
              </div>-->
            </div>

            <div class="d-flex flex-wrap justify-content-between">
              <div class="col-md-12 py-4" style="background-color: #1ab474; text-align:center;">
                <label for="" class="header__publish mainButton">Contactar al Vendedor</label>
                <form style="width: 100%;" method="POST" action="<?php echo e(route('mensaje.post')); ?>">    
                <?php echo csrf_field(); ?>     
                    <div class="form-group"><input placeholder="Email" class="form-control post__input maininput my-2 w-100" type="text" name="correo" value="<?php echo e(old('nombre')); ?>" required>
                      <?php echo $errors->first('nombre', '<span class="error">:message</span>'); ?></div>
              
                    <div class="form-group">
                      <textarea rows="6" placeholder="Mensaje" class="form-control post__input maininput my-2 w-100" type="text" name="mensaje" value="" required></textarea>
                      <?php echo $errors->first('orden', '<span class="error">:message</span>'); ?></div>
                    <input class="header__publish mainButton" type="submit" value="Enviar Mensaje">        
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <script>
    function change(e){
        //e.preventDefault();
        var current = document.getElementsByClassName("active");
        console.log("item_"+e);
        current[0].classList.remove("active");

        var newCurrent = document.getElementById("item_"+e)
        newCurrent.classList.add('active');
        //$(this).addClass('active');
    }

  </script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutdescripcion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/general/inmueble.blade.php ENDPATH**/ ?>