

<?php $__env->startSection('contenido'); ?>
    <div class="body-one-inmueble">
        <div class="container py-4">
            <div class="row py-4">
                <div class="col-md-7">
                    <h3><?php echo e($inmueble->titulo); ?></h3>
                </div>
                <div class="col-md-5" style="text-align: right">
                    <h4>S/. <?php echo e($inmueble->precio); ?></h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8">
                    <img src="<?php echo e($inmueble->fotos[0]->url_imagen); ?>" style="width: 100%" alt="Card image cap">

                    <div class="row pt-4">
                        <div class="col-md-12">
                            <h4>Descripción</h4>
                        </div>
                    </div>    

                    <div class="row py-4">
                        <div class="col-md-12">
                        <?php echo e($inmueble->descripción); ?>

                        </div>
                    </div>

                    <div class="row py-4">
                        <div class="col-md-12">
                            <h4>Ubicación</h4>
                        </div>
                    </div>    

                    <img src="<?php echo e($inmueble->fotos[0]->url_imagen); ?>" style="width: 100%" alt="Card image cap">

                </div>
                <div class="col-md-4">
                    <div class="row">
                        <?php $__currentLoopData = $inmueble->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 p-1">
                                <img src="<?php echo e($foto->url_imagen); ?>" style="width: 100%" alt="Card image cap">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--<div class="col-md-4 p-1">
                            <img src="<?php echo e(asset('storage/interiores.PNG')); ?>" style="width: 100%" alt="Card image cap">
                        </div>
                        <div class="col-md-4 p-1">
                            <img src="<?php echo e(asset('storage/interiores.PNG')); ?>" style="width: 100%" alt="Card image cap">
                        </div>
                        <div class="col-md-4 p-1">
                            <img src="<?php echo e(asset('storage/interiores.PNG')); ?>" style="width: 100%" alt="Card image cap">
                        </div>
                        <div class="col-md-4 p-1">
                            <img src="<?php echo e(asset('storage/interiores.PNG')); ?>" style="width: 100%" alt="Card image cap">
                        </div>
                        <div class="col-md-4 p-1">
                            <img src="<?php echo e(asset('storage/interiores.PNG')); ?>" style="width: 100%" alt="Card image cap">
                        </div>
                        <div class="col-md-4 p-1">
                            <img src="<?php echo e(asset('storage/interiores.PNG')); ?>" style="width: 100%" alt="Card image cap">
                        </div>
                        <div class="col-md-4 p-1">
                            <img src="<?php echo e(asset('storage/interiores.PNG')); ?>" style="width: 100%" alt="Card image cap">
                        </div>
                        <div class="col-md-4 p-1">
                            <img src="<?php echo e(asset('storage/interiores.PNG')); ?>" style="width: 100%" alt="Card image cap">
                        </div>-->
                    </div>
                </div>
            </div>
        </div>
    </div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/general/inmueble.blade.php ENDPATH**/ ?>