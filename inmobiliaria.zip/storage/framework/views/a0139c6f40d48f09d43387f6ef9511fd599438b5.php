

<?php $__env->startSection('contenido'); ?>
    <h2>Vista por Busqueda</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inmobiliaria\resources\views/general/busqueda.blade.php ENDPATH**/ ?>