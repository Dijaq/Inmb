@extends('layout')

@section('contenido')
    <h2>Vista por Busqueda</h2>
@stop