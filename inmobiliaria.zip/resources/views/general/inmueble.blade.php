@extends('layout')

@section('contenido')
    <h2>Vista de un Inmueble</h2>
@stop