@extends('layout')

@section('contenido')
    <h2>Indice General</h2>
@stop