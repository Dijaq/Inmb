<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class UbicacionProvincia extends Model
{
    public $table = 'ubi_provincias';
}
