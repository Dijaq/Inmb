<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InmuebleFotos extends Model
{
    public $table = 'inmueble_fotos';
}
