<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InmuebleVideos extends Model
{
    public $table = 'inmueble_videos';
}
