<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class UbicacionDistrito extends Model
{
    public $table = 'ubi_distritos';
}
